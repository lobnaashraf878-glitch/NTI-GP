# AI IT Operations Assistant

A compact local MVP for investigating IT tickets in an **existing** MySQL database. Gradio provides chat and a dashboard; Gemini function calling asks controlled Python tools for evidence; SQLAlchemy reflects the real schema and runs read-only queries. The app does not create or modify application tables.

## Architecture

- `app.py` — Gradio chat, dashboard, schema view, local launch.
- `config.py` — environment-based configuration and safe SQLAlchemy URL construction.
- `database.py` — MySQL engine, metadata reflection, controlled SELECT validation and query execution.
- `analytics.py` — schema-aware metrics and Plotly charts.
- `agent.py` — `google-genai` client, function declarations, bounded multi-round tool orchestration.
- `tests/` — offline tests; fixtures are synthetic and are **not** production data.

## Requirements

- Python 3.11 or newer.
- Your existing MySQL server and database `nti_support_dwh` reachable from the computer running this app.
- A Gemini API key and access to the model configured in `GEMINI_MODEL`.

## Setup — Windows PowerShell

Run in this folder:

```powershell
py -3.11 -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements.txt
Copy-Item .env.example .env
```

Open `.env` and fill `GEMINI_API_KEY`, `GEMINI_MODEL`, and MySQL settings. Create a Gemini key at <https://aistudio.google.com/apikey>. The code uses the official `google-genai` SDK, not the legacy Gemini SDK.

Use `MYSQL_USER` and `MYSQL_PASSWORD` for a database account with read-only access. For your existing local setup only, you may explicitly configure `MYSQL_USER=root` and `MYSQL_PASSWORD=` (empty value); the application supports this. This is not recommended for a shared database—prefer the dedicated reader account below.

### Create a dedicated MySQL read-only user

Run these commands in MySQL as an administrator. Replace the example password before running them. These commands add a database account and grants only `SELECT`; they do not change existing tables or records.

```sql
CREATE USER 'it_ops_reader'@'localhost' IDENTIFIED BY 'replace_with_a_strong_password';
GRANT SELECT ON nti_support_dwh.* TO 'it_ops_reader'@'localhost';
FLUSH PRIVILEGES;
```

If the app connects through TCP as `127.0.0.1`, use a matching MySQL account host (commonly `'it_ops_reader'@'127.0.0.1'`) or configure a host pattern according to your MySQL security policy. Verify the account with your DBA. Do not use `root` for the regular app session.

## Inspect, test, run

With the virtual environment activated:

```powershell
python -c "from database import inspect_schema; print(inspect_schema())"
pytest -q
python app.py
```

Open <http://127.0.0.1:7860>. The app binds to localhost and passes `share=False`, so it does not create a public Gradio share link by default. On Linux/macOS, activate with `source .venv/bin/activate` and use the same `pip`, `pytest`, and `python app.py` commands.

## How a question reaches MySQL

1. The chat passes a bounded recent conversation to Gemini.
2. Gemini may request a declared tool such as status counts or ticket trends.
3. Python executes the predefined function or validates `run_readonly_sql` using SQLGlot and the reflected schema.
4. The app returns a compact result to Gemini for a grounded explanation. Tool results can also become a chart/table in the UI.

Gemini does not get database credentials and does not execute SQL itself. Predefined analytics use bound SQL parameters for date filters. Free-form generated SQL is restricted to one parsed read-only SELECT, approved tables, reflected columns, and a result limit. A SELECT-only MySQL account remains the required second security layer.

## What the schema supports / limitations

The app checks metadata instead of assuming all columns and foreign keys exist. Status, priority, issue category, creation trends, SLA flag values, escalation values, resolution/response metrics, satisfaction, reopens, and complexity are shown only when the required columns/relationships are available. Unknown categorical values are reported as observed rather than silently classified.

- `AssignedAtKey` is treated as a date key, not an employee key.
- `ResolvedByKey` can support counts associated with resolving staff only if its join to `dimstaff.StaffKey` is valid. It does **not** establish assigned workload.
- `ResolutionTimeMinutes`, `ResolutionWallclockMinutes`, and `PausedMinutes` remain distinct; paused time is not subtracted again.
- SLA status fields are inspected as raw categories. The app gives a breached percentage only when observed values can be unambiguously interpreted. `SlaTargetHours` and `SlaBreachMargin` are not used to infer a business SLA rule without an agreed definition.
- Ticket notes/descriptions may contain sensitive or untrusted text. Normal analytics avoid customer email addresses; do not expose broad row-level details to an LLM.
- This is an analysis/decision-support app only: it does not create, assign, close, or change tickets.

## Configuration

See `.env.example`. `GEMINI_MODEL` can be changed without editing source code. There is no automatic model fallback. `SQL_MAX_ROWS` is clamped to a safe range; `DB_CONNECT_TIMEOUT` sets the MySQL connection timeout. The Gemini client uses a 30-second request timeout and one retry for likely transient failures.

## Troubleshooting

- **Database unavailable:** verify MySQL is running, `MYSQL_HOST`, port, database, username/password, the account host grants, and network access. Run the schema-inspection command above.
- **Missing expected tables:** check the selected schema is `nti_support_dwh`; the app will not create replacements.
- **Access denied:** create/use a SELECT-only user with access to the eight relevant tables.
- **Gemini key missing/invalid:** set `GEMINI_API_KEY` in `.env` and verify it in Google AI Studio. Never paste the key into chat or commit `.env`.
- **Model not available:** set `GEMINI_MODEL` to a supported model enabled for your Gemini API project. The app reports the configured model and does not silently switch models.
- **Quota/rate limit:** inspect API quota/billing/availability for the Google project and retry after limits reset.
- **SQL rejected:** use a more specific request or a predefined analysis. Generated SQL that references unknown columns, unapproved tables, multiple statements, or write operations is rejected.

## Security notes

Keep `.env` private; it is excluded by `.gitignore`. Do not enable Gradio sharing on a machine containing sensitive ticket data. Run as a least-privilege MySQL account. SQL parser validation is defense in depth—not a replacement for database privileges, backups, access controls, and organizational privacy rules.

## References

- Gemini function calling: <https://ai.google.dev/gemini-api/docs/function-calling>
- Official Google Gen AI SDK: <https://ai.google.dev/gemini-api/docs/libraries>
- SQLAlchemy MySQL dialect: <https://docs.sqlalchemy.org/en/20/dialects/mysql.html>
- Gradio Blocks: <https://www.gradio.app/docs/gradio/blocks>
- SQLGlot: <https://sqlglot.com/sqlglot.html>
